"""
Create tiny RANDOM files in the expected dataset formats, for testing the code path only.
Results produced from these files are meaningless and must never be reported.
"""
import os
import sys

import numpy as np
import pandas as pd

root = sys.argv[1] if len(sys.argv) > 1 else "fake_data"
r = np.random.default_rng(0)

os.makedirs(f"{root}/mitbih", exist_ok=True)
for name, n in (("mitbih_train.csv", 1200), ("mitbih_test.csv", 300)):
    c = r.choice(5, n, p=[.7, .08, .12, .03, .07])
    X = r.random((n, 187)) + 0.3 * c[:, None]
    pd.DataFrame(np.c_[X, c]).to_csv(f"{root}/mitbih/{name}", header=False, index=False)

os.makedirs(f"{root}/mimic", exist_ok=True)
n = 1200
X = r.normal(size=(n, 40)); X[r.random((n, 40)) < 0.05] = np.nan
y = (r.random(n) < 0.16).astype(int)
df = pd.DataFrame(X, columns=[f"f{i}" for i in range(40)]); df["label"] = y; df["hadm_id"] = range(n)
df.to_csv(f"{root}/mimic/mimic_readmission.csv", index=False)

from PIL import Image  # noqa: E402
os.makedirs(f"{root}/isic2019/ISIC_2019_Training_Input", exist_ok=True)
cls = ["MEL", "NV", "BCC", "AK", "BKL", "DF", "VASC", "SCC", "UNK"]
rows = []
for i in range(400):
    k = r.choice(8, p=[.18, .5, .13, .03, .1, .01, .01, .04])
    name = f"ISIC_{i:07d}"
    Image.fromarray((r.random((32, 32, 3)) * 255).astype("uint8")).save(
        f"{root}/isic2019/ISIC_2019_Training_Input/{name}.jpg")
    rows.append({"image": name, **{c: float(j == k) for j, c in enumerate(cls)}})
pd.DataFrame(rows).to_csv(f"{root}/isic2019/ISIC_2019_Training_GroundTruth.csv", index=False)
print("fake data written to", root)
