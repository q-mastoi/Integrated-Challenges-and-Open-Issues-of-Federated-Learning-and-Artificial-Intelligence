"""
Dataset loading and preprocessing for the four healthcare tasks (Section 5.3, Table 2).

Expected layout under --data-dir (see README for download instructions):

  mitbih/mitbih_train.csv, mitbih/mitbih_test.csv
        Kaggle "ECG Heartbeat Categorization" release of the MIT-BIH Arrhythmia
        Database: 187 samples per beat (125 Hz) + class label 0-4
        (0 = normal N; 1-4 = S, V, F, Q). 87,554 + 21,892 = 109,446 beats.
  mimic/mimic_readmission.csv
        Output of scripts/build_mimic_readmission.py (numeric feature columns plus
        a binary "label" column = 30-day readmission).
  isic2019/ISIC_2019_Training_GroundTruth.csv, isic2019/ISIC_2019_Training_Input/*.jpg
        ISIC 2019 training set (25,331 images).
  radiology: nothing to download - generated deterministically (18,000 images).

Every task is a binary classification problem. Each loader returns a TaskData
object holding the training pool, the held-out test set, the binary labels and
the fine-grained labels used for Dirichlet partitioning.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

SPLIT_SEED = 2024  # fixed train/test split for every seed and condition


# ----------------------------------------------------------------- containers
class ArrayDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = torch.from_numpy(np.ascontiguousarray(X, dtype=np.float32))
        self.y = torch.from_numpy(np.asarray(y, dtype=np.int64))

    def __len__(self):
        return len(self.y)

    def __getitem__(self, i):
        return self.X[i], self.y[i]


class ImageFileDataset(Dataset):
    """Lazily loads image files; transform is applied per sample."""

    def __init__(self, paths, labels, transform):
        self.paths = list(paths)
        self.labels = np.asarray(labels, dtype=np.int64)
        self.transform = transform

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, i):
        from PIL import Image
        with Image.open(self.paths[i]) as im:
            img = self.transform(im.convert("RGB"))
        return img, int(self.labels[i])


class SyntheticRadiologyDataset(Dataset):
    """
    Deterministic synthetic radiographs (Table 2: 18,000 images, 50% positive).

    Each image is a smooth random tissue-like background; positive images contain
    one faint elliptical opacity of random size, position and contrast. Images
    are generated on the fly from (base_seed, index), so no storage is needed
    and every run sees identical data. Pixels are normalised to [0, 1];
    training samples receive additive Gaussian noise (sigma = 0.01).
    """

    def __init__(self, indices, labels, img_size=224, base_seed=7, train=False):
        self.indices = np.asarray(indices)
        self.labels = np.asarray(labels, dtype=np.int64)
        self.img_size = img_size
        self.base_seed = base_seed
        self.train = train

    def __len__(self):
        return len(self.indices)

    def _render(self, idx, label):
        g = torch.Generator().manual_seed(int(self.base_seed * 1_000_003 + idx))
        s = self.img_size
        low = torch.rand(1, 1, 14, 14, generator=g)
        bg = torch.nn.functional.interpolate(low, size=(s, s), mode="bicubic",
                                             align_corners=False)[0, 0]
        bg = 0.35 + 0.3 * (bg - bg.min()) / (bg.max() - bg.min() + 1e-6)
        if label == 1:
            yy, xx = torch.meshgrid(torch.arange(s), torch.arange(s), indexing="ij")
            cx, cy = (torch.rand(2, generator=g) * 0.6 + 0.2) * s
            rx, ry = (torch.rand(2, generator=g) * 0.08 + 0.04) * s
            amp = 0.08 + 0.12 * torch.rand(1, generator=g)
            blob = torch.exp(-(((xx - cx) / rx) ** 2 + ((yy - cy) / ry) ** 2))
            bg = bg + amp * blob
        noise = 0.03 * torch.randn(s, s, generator=g)
        return (bg + noise).clamp(0, 1)

    def __getitem__(self, i):
        idx, label = int(self.indices[i]), int(self.labels[i])
        img = self._render(idx, label)
        if self.train:
            img = (img + 0.01 * torch.randn_like(img)).clamp(0, 1)
        return img.unsqueeze(0).repeat(3, 1, 1), label


@dataclass
class TaskData:
    name: str
    kind: str                    # "tabular" or "image"
    train: Dataset               # training pool (validation and client splits drawn from it)
    test: Dataset                # held-out test set
    y_train: np.ndarray          # binary labels of the training pool
    strat_train: np.ndarray      # fine-grained labels used for Dirichlet partitioning
    input_dim: int = 0
    raw_train_bytes: int = 0     # bytes a centralized approach must transfer (raw data)
    class_weighted: bool = False
    notes: dict = field(default_factory=dict)


def _stratified_split(labels, test_frac, seed):
    rng = np.random.default_rng(seed)
    tr, te = [], []
    for c in np.unique(labels):
        ids = rng.permutation(np.where(labels == c)[0])
        k = int(round(test_frac * len(ids)))
        te.extend(ids[:k]); tr.extend(ids[k:])
    return np.array(sorted(tr)), np.array(sorted(te))


# ----------------------------------------------------------------- MIT-BIH
def _bandpass(X, fs=125.0, lo=0.5, hi=45.0, order=3):
    from scipy.signal import butter, filtfilt
    b, a = butter(order, [lo / (fs / 2), hi / (fs / 2)], btype="band")
    return filtfilt(b, a, X, axis=1).astype(np.float32)


def load_mitbih(data_dir, bandpass=True, limit=0, seed=0):
    d = os.path.join(data_dir, "mitbih")
    tr = pd.read_csv(os.path.join(d, "mitbih_train.csv"), header=None).values
    te = pd.read_csv(os.path.join(d, "mitbih_test.csv"), header=None).values
    Xtr, ctr = tr[:, :-1].astype(np.float32), tr[:, -1].astype(int)
    Xte, cte = te[:, :-1].astype(np.float32), te[:, -1].astype(int)
    if limit:
        r = np.random.default_rng(seed)
        i = r.choice(len(Xtr), min(limit, len(Xtr)), replace=False); Xtr, ctr = Xtr[i], ctr[i]
        j = r.choice(len(Xte), min(limit // 4 or 1, len(Xte)), replace=False); Xte, cte = Xte[j], cte[j]
    if bandpass:
        Xtr, Xte = _bandpass(Xtr), _bandpass(Xte)
    mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-6          # z-score with training statistics
    Xtr, Xte = (Xtr - mu) / sd, (Xte - mu) / sd
    ytr, yte = (ctr != 0).astype(int), (cte != 0).astype(int)
    return TaskData("mitbih", "tabular", ArrayDataset(Xtr, ytr), ArrayDataset(Xte, yte),
                    ytr, ctr, input_dim=Xtr.shape[1], raw_train_bytes=int(Xtr.nbytes),
                    notes={"n_train": len(ytr), "n_test": len(yte),
                           "positive_rate": float(np.r_[ytr, yte].mean())})


# ----------------------------------------------------------------- MIMIC-III
def load_mimic(data_dir, limit=0, seed=0):
    df = pd.read_csv(os.path.join(data_dir, "mimic", "mimic_readmission.csv"))
    y = df.pop("label").astype(int).values
    for col in ("subject_id", "hadm_id", "SUBJECT_ID", "HADM_ID"):
        if col in df.columns:
            df.pop(col)
    X = df.astype(np.float32).values
    if limit:
        i = np.random.default_rng(seed).choice(len(X), min(limit, len(X)), replace=False)
        X, y = X[i], y[i]
    tr, te = _stratified_split(y, 0.2, SPLIT_SEED)
    Xtr, Xte = X[tr], X[te]
    means = np.nanmean(Xtr, 0); means = np.where(np.isnan(means), 0, means)   # mean imputation
    Xtr = np.where(np.isnan(Xtr), means, Xtr); Xte = np.where(np.isnan(Xte), means, Xte)
    mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-6                                   # standard scaling
    Xtr, Xte = (Xtr - mu) / sd, (Xte - mu) / sd
    return TaskData("mimic", "tabular", ArrayDataset(Xtr, y[tr]), ArrayDataset(Xte, y[te]),
                    y[tr], y[tr], input_dim=X.shape[1], raw_train_bytes=int(Xtr.astype(np.float32).nbytes),
                    class_weighted=True,
                    notes={"n_train": len(tr), "n_test": len(te), "positive_rate": float(y.mean())})


# ----------------------------------------------------------------- ISIC 2019
ISIC_CLASSES = ["MEL", "NV", "BCC", "AK", "BKL", "DF", "VASC", "SCC", "UNK"]


def _image_transforms(img_size):
    from torchvision import transforms as T
    norm = T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])      # ImageNet normalisation
    train = T.Compose([T.Resize((img_size, img_size)), T.RandomHorizontalFlip(), T.ToTensor(), norm])
    test = T.Compose([T.Resize((img_size, img_size)), T.ToTensor(), norm])
    return train, test


def load_isic(data_dir, img_size=224, malignant=("MEL", "BCC", "SCC"), limit=0, seed=0):
    d = os.path.join(data_dir, "isic2019")
    gt = pd.read_csv(os.path.join(d, "ISIC_2019_Training_GroundTruth.csv"))
    cls_cols = [c for c in ISIC_CLASSES if c in gt.columns]
    fine = gt[cls_cols].values.argmax(1)
    y = np.isin(np.array(cls_cols)[fine], malignant).astype(int)
    img_dir = os.path.join(d, "ISIC_2019_Training_Input")
    paths = np.array([os.path.join(img_dir, f"{n}.jpg") for n in gt["image"]])
    if limit:
        i = np.random.default_rng(seed).choice(len(y), min(limit, len(y)), replace=False)
        paths, y, fine = paths[i], y[i], fine[i]
    tr, te = _stratified_split(fine, 0.2, SPLIT_SEED)
    t_train, t_test = _image_transforms(img_size)
    raw = int(sum(os.path.getsize(p) for p in paths[tr] if os.path.exists(p)))
    return TaskData("isic", "image", ImageFileDataset(paths[tr], y[tr], t_train),
                    ImageFileDataset(paths[te], y[te], t_test), y[tr], fine[tr],
                    raw_train_bytes=raw,
                    notes={"n_train": len(tr), "n_test": len(te), "positive_rate": float(y.mean()),
                           "malignant_classes": list(malignant)})


# ----------------------------------------------------------------- synthetic radiology
def load_radiology(img_size=224, n=18000, limit=0, seed=0):
    if limit:
        n = min(n, limit)
    labels = np.random.default_rng(0).permutation(np.r_[np.zeros(n // 2), np.ones(n - n // 2)]).astype(int)
    tr, te = _stratified_split(labels, 0.2, SPLIT_SEED)
    train = SyntheticRadiologyDataset(tr, labels[tr], img_size, train=True)
    test = SyntheticRadiologyDataset(te, labels[te], img_size, train=False)
    return TaskData("radiology", "image", train, test, labels[tr], labels[tr],
                    raw_train_bytes=int(len(tr) * img_size * img_size),   # 8-bit grayscale
                    notes={"n_train": len(tr), "n_test": len(te), "positive_rate": float(labels.mean())})


def load_task(name, data_dir, img_size=224, limit=0, seed=0, bandpass=True):
    if name == "mitbih":
        return load_mitbih(data_dir, bandpass=bandpass, limit=limit, seed=seed)
    if name == "mimic":
        return load_mimic(data_dir, limit=limit, seed=seed)
    if name == "isic":
        return load_isic(data_dir, img_size=img_size, limit=limit, seed=seed)
    if name == "radiology":
        return load_radiology(img_size=img_size, limit=limit, seed=seed)
    raise ValueError(f"unknown dataset: {name}")
