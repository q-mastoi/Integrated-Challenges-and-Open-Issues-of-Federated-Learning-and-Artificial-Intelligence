"""Local training (FedAvg / FedProx / DP-SGD), evaluation and the seven evaluation metrics (Section 5.5)."""
import math

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import (average_precision_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score)
from torch.utils.data import DataLoader, Subset


def make_loader(dataset, indices, batch_size, shuffle, seed=0, workers=0):
    g = torch.Generator().manual_seed(seed)
    return DataLoader(Subset(dataset, list(map(int, indices))), batch_size=batch_size,
                      shuffle=shuffle, generator=g if shuffle else None,
                      num_workers=workers, drop_last=False)


def class_weights(labels):
    """Inverse-frequency weights n / (2 n_c); used for MIMIC-III (class-weighted loss)."""
    labels = np.asarray(labels)
    w = []
    for c in (0, 1):
        n_c = (labels == c).sum()
        w.append(len(labels) / (2.0 * n_c) if n_c > 0 else 1.0)
    return torch.tensor(w, dtype=torch.float32)


def local_train(model, loader, epochs, lr, device, mu=0.0, global_weights=None,
                cw=None, dp=None, on_epoch_end=None):
    """
    Train `model` for `epochs` local epochs with Adam.

    mu > 0       : FedProx proximal term (mu/2)||w - w_global||^2 (Li et al., 2020).
    dp = {"noise_multiplier": s, "max_grad_norm": C}
                 : DP-SGD via Opacus with Poisson sampling (Abadi et al., 2016).
    on_epoch_end : optional callback(epoch, model) - used by centralized training
                   to log validation accuracy after every epoch.
    Returns the trained (unwrapped) model and the number of optimisation steps.
    """
    model.to(device).train()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    lossf = nn.CrossEntropyLoss(weight=cw.to(device) if cw is not None else None)
    if dp is not None:
        if mu > 0:
            raise ValueError("FedProx with DP-SGD is not supported: Opacus clips per-sample "
                             "gradients and would silently drop the proximal term.")
        from opacus import PrivacyEngine
        engine = PrivacyEngine(accountant="rdp")
        model, opt, loader = engine.make_private(
            module=model, optimizer=opt, data_loader=loader,
            noise_multiplier=dp["noise_multiplier"], max_grad_norm=dp["max_grad_norm"],
            poisson_sampling=True)
    g_params = None
    if mu > 0:
        g_params = [torch.as_tensor(w, device=device)
                    for w, (k, _) in zip(global_weights, model.state_dict().items())
                    if k in dict(model.named_parameters())]
    steps = 0
    unwrap = lambda m: m._module if hasattr(m, "_module") else m  # noqa: E731
    for epoch in range(1, epochs + 1):
        model.train()
        for xb, yb in loader:
            if len(yb) == 0:          # Poisson sampling can yield an empty batch
                continue
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad()
            loss = lossf(model(xb), yb)
            if mu > 0:
                loss = loss + (mu / 2.0) * sum(((p - g) ** 2).sum()
                                               for p, g in zip(model.parameters(), g_params))
            loss.backward()
            opt.step()
            steps += 1
        if on_epoch_end is not None:
            on_epoch_end(epoch, unwrap(model))
            model.to(device)
    if hasattr(model, "_module"):          # detach Opacus hooks so the model can be reused
        model.remove_hooks()
    return unwrap(model).cpu(), steps


@torch.no_grad()
def predict(model, loader, device):
    model.to(device).eval()
    probs, ys, loss_sum, n = [], [], 0.0, 0
    lossf = nn.CrossEntropyLoss(reduction="sum")
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        out = model(xb)
        loss_sum += float(lossf(out, yb)); n += len(yb)
        probs.append(torch.softmax(out, 1)[:, 1].cpu().numpy()); ys.append(yb.cpu().numpy())
    model.cpu()
    return np.concatenate(ys), np.concatenate(probs), loss_sum / max(n, 1)


def binary_metrics(y, p, threshold=0.5):
    """Accuracy, sensitivity, specificity, precision, F1 (all %), AUC-ROC and AUPRC."""
    yh = (p >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, yh, labels=[0, 1]).ravel()
    both = len(np.unique(y)) == 2
    return {
        "accuracy": 100.0 * (tp + tn) / len(y),
        "sensitivity": 100.0 * recall_score(y, yh, zero_division=0),
        "specificity": 100.0 * tn / (tn + fp) if (tn + fp) else float("nan"),
        "precision": 100.0 * precision_score(y, yh, zero_division=0),
        "f1": 100.0 * f1_score(y, yh, zero_division=0),
        "auc_roc": float(roc_auc_score(y, p)) if both else float("nan"),
        "auprc": float(average_precision_score(y, p)) if both else float("nan"),
    }


def steps_per_epoch(n, batch_size):
    return max(1, math.ceil(n / batch_size))
