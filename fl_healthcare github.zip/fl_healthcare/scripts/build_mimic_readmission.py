#!/usr/bin/env python3
"""
Build the MIMIC-III 30-day readmission dataset (Section 5.3, Table 2).

Requires credentialed PhysioNet access to MIMIC-III v1.4. Reads:
  ADMISSIONS.csv(.gz), PATIENTS.csv(.gz), DIAGNOSES_ICD.csv(.gz)

Cohort
  - adult admissions (age >= 18 at admission)
  - excludes NEWBORN admissions and admissions ending in in-hospital death
Label
  - 1 if the same patient is readmitted within --window days (default 30) of discharge
Features
  - age (capped at 90; MIMIC shifts ages > 89), sex, admission type, insurance,
    length of stay (days), number of diagnoses, number of prior admissions
  - one-hot indicators for the --top-k most frequent 3-character ICD-9 categories
Missing values are left as NaN here; mean imputation and standard scaling are
fitted on the training split inside flhc/data.py, so no test information leaks.

  python scripts/build_mimic_readmission.py --mimic-dir /path/to/mimic-iii-1.4 \
      --out data/mimic/mimic_readmission.csv
"""
import argparse
import os

import pandas as pd


def read(d, name, **kw):
    for ext in (".csv.gz", ".csv"):
        p = os.path.join(d, name + ext)
        if os.path.exists(p):
            return pd.read_csv(p, **kw)
    raise FileNotFoundError(f"{name}.csv(.gz) not found in {d}")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--mimic-dir", required=True)
    p.add_argument("--out", default="data/mimic/mimic_readmission.csv")
    p.add_argument("--window", type=int, default=30)
    p.add_argument("--top-k", type=int, default=100)
    a = p.parse_args()

    adm = read(a.mimic_dir, "ADMISSIONS", parse_dates=["ADMITTIME", "DISCHTIME"])
    pat = read(a.mimic_dir, "PATIENTS", parse_dates=["DOB"])
    dx = read(a.mimic_dir, "DIAGNOSES_ICD", dtype={"ICD9_CODE": str})

    adm = adm.sort_values(["SUBJECT_ID", "ADMITTIME"]).reset_index(drop=True)
    adm["NEXT_ADMIT"] = adm.groupby("SUBJECT_ID")["ADMITTIME"].shift(-1)
    adm["DAYS_TO_NEXT"] = (adm["NEXT_ADMIT"] - adm["DISCHTIME"]).dt.total_seconds() / 86400
    adm["label"] = ((adm["DAYS_TO_NEXT"] >= 0) & (adm["DAYS_TO_NEXT"] <= a.window)).astype(int)
    adm["PRIOR_ADMISSIONS"] = adm.groupby("SUBJECT_ID").cumcount()
    adm["LOS_DAYS"] = (adm["DISCHTIME"] - adm["ADMITTIME"]).dt.total_seconds() / 86400

    df = adm.merge(pat[["SUBJECT_ID", "GENDER", "DOB"]], on="SUBJECT_ID", how="left")
    # year arithmetic avoids timedelta overflow on MIMIC's shifted dates of birth
    df["AGE"] = (df["ADMITTIME"].dt.year - df["DOB"].dt.year).clip(upper=90)
    df = df[(df["AGE"] >= 18) & (df["ADMISSION_TYPE"] != "NEWBORN") & (df["HOSPITAL_EXPIRE_FLAG"] == 0)]

    dx = dx.dropna(subset=["ICD9_CODE"])
    dx["ICD3"] = dx["ICD9_CODE"].str[:3]
    ndx = dx.groupby("HADM_ID").size().rename("N_DIAGNOSES")
    top = dx[dx.HADM_ID.isin(df.HADM_ID)]["ICD3"].value_counts().index[:a.top_k]
    onehot = (pd.crosstab(dx.loc[dx.ICD3.isin(top), "HADM_ID"], dx.loc[dx.ICD3.isin(top), "ICD3"]) > 0).astype(int)
    onehot.columns = [f"ICD9_{c}" for c in onehot.columns]

    out = df[["HADM_ID", "AGE", "LOS_DAYS", "PRIOR_ADMISSIONS"]].copy()
    out["MALE"] = (df["GENDER"] == "M").astype(int)
    out = out.join(pd.get_dummies(df["ADMISSION_TYPE"], prefix="ADMTYPE").astype(int))
    out = out.join(pd.get_dummies(df["INSURANCE"], prefix="INS").astype(int))
    out = out.merge(ndx, left_on="HADM_ID", right_index=True, how="left")
    out = out.merge(onehot, left_on="HADM_ID", right_index=True, how="left")
    icd_cols = [c for c in out.columns if c.startswith("ICD9_")]
    out[icd_cols] = out[icd_cols].fillna(0).astype(int)
    out["label"] = df["label"].values
    out = out.rename(columns={"HADM_ID": "hadm_id"})

    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    out.to_csv(a.out, index=False)
    print(f"Wrote {a.out}: {len(out)} admissions, {out.shape[1] - 2} features, "
          f"{100 * out['label'].mean():.1f}% readmitted within {a.window} days")


if __name__ == "__main__":
    main()
