#!/usr/bin/env bash
# Code-path test on tiny RANDOM data. Outputs are meaningless - never report them.
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
TMP="${1:-$(mktemp -d)}"
python3 "$HERE/tests/make_fake_data.py" "$TMP/data"
python3 "$HERE/run_all.py" --datasets mitbih mimic isic radiology --seeds 42 123 \
  --out-root "$TMP/outputs" --data-dir "$TMP/data" \
  -- --rounds 2 --local-epochs 1 --img-size 32 --limit 400 --batch-size 16
python3 "$HERE/analyze.py" --out-root "$TMP/outputs" --report "$TMP/report"
echo "Smoke test finished: $TMP/report"
