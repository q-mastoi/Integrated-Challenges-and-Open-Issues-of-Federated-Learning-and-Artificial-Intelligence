"""
Differential-privacy accounting (Section 5.4): Renyi DP accountant with (epsilon, delta) conversion.

Privacy is sample-level DP for each client's local dataset. Each client runs
DP-SGD with Poisson sampling at rate q_i = 1 / steps_per_epoch_i for
E local epochs in each of R rounds, i.e. R * E * steps_per_epoch_i noisy steps
in total. The reported epsilon is the maximum over clients.
"""
from opacus.accountants import RDPAccountant
from opacus.accountants.utils import get_noise_multiplier


def epsilon_spent(noise_multiplier, sample_rate, steps, delta):
    if steps <= 0:
        return 0.0
    acc = RDPAccountant()
    acc.history = [(noise_multiplier, sample_rate, int(steps))]
    return float(acc.get_epsilon(delta))


def sigma_for_target(target_epsilon, delta, sample_rate, total_steps):
    """Smallest noise multiplier that keeps epsilon <= target over the whole training horizon."""
    return float(get_noise_multiplier(target_epsilon=target_epsilon, target_delta=delta,
                                      sample_rate=sample_rate, steps=int(total_steps),
                                      accountant="rdp", epsilon_tolerance=0.005))
